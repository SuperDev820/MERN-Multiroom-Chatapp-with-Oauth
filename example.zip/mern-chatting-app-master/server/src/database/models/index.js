const Users = require('./Users');
const Rooms = require('./Rooms');
const Chats = require('./Chats');

module.exports = {
  Users,
  Rooms,
  Chats,
};
