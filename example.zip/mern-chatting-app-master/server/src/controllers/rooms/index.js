const getRooms = require('./getRooms');
const addRoom = require('./createRoom');

module.exports = {
  getRooms,
  addRoom,
};
