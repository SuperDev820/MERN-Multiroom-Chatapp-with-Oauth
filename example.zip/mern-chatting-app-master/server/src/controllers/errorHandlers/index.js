const clientError = require('./clientError');
const serverError = require('./serverError');

module.exports = {
  clientError,
  serverError,
};
